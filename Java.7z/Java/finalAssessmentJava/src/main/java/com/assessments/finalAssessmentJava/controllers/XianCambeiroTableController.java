package com.assessments.finalAssessmentJava.controllers;

import com.assessments.finalAssessmentJava.models.UsersInfo;
import com.assessments.finalAssessmentJava.services.XianCambeiroTableService;
import com.assessments.finalAssessmentJava.services.implementations.XianCambeiroTableServiceImpl;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("registers")
public class XianCambeiroTableController {

    @Autowired
    public XianCambeiroTableServiceImpl service;

    public XianCambeiroTableController(XianCambeiroTableServiceImpl service){
        this.service = service;
    }

    @GetMapping("/getRegister/{id}")
    public UsersInfo getInfo(int id){
        return service.getInfo(id);
    }

    @GetMapping("/getAllRegisters")
    public List<UsersInfo> getAll(){
        return service.getAll();
    }

    @PostMapping("/createRegister")
    public String createInfo(@RequestBody UsersInfo register){
        service.createInfo(register);
        return "Register created successfully :D";
    }

    @PutMapping("/updateRegister")
    public String updateInfo(@RequestBody UsersInfo register){
        service.updateInfo(register);
        return "Register updated successfully :D";
    }

    @DeleteMapping("/deleteRegister/{id}")
    public String deleteInfo(int id){
        service.deleteInfo(id);
        return "Register deleted successfully :D";
    }

}
