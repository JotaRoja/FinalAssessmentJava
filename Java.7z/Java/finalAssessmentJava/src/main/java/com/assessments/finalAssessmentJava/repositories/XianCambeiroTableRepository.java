package com.assessments.finalAssessmentJava.repositories;

import com.assessments.finalAssessmentJava.models.UsersInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface XianCambeiroTableRepository extends JpaRepository<UsersInfo, Integer> {

}
