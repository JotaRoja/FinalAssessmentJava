package com.assessments.finalAssessmentJava.services.implementations;

import com.assessments.finalAssessmentJava.models.UsersInfo;
import com.assessments.finalAssessmentJava.repositories.XianCambeiroTableRepository;
import com.assessments.finalAssessmentJava.services.XianCambeiroTableService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class XianCambeiroTableServiceImpl implements XianCambeiroTableService {

    @Autowired
    XianCambeiroTableRepository repository;

    public XianCambeiroTableServiceImpl(XianCambeiroTableRepository repository){
        this.repository = repository;
    }

    @Override
    public UsersInfo getInfo(int id) {
        return repository.findById(id).get();
    }

    @Override
    public List<UsersInfo> getAll() {
        return repository.findAll();
    }

    @Override
    public String createInfo(UsersInfo info) {
        repository.save(info);
        return "Successful save";
    }

    @Override
    public String updateInfo(UsersInfo info) {
        repository.save(info);
        return "Successfully updated";
    }

    @Override
    public String deleteInfo(int id) {
        repository.deleteById(id);
        return "Successfully deleted";
    }
}
