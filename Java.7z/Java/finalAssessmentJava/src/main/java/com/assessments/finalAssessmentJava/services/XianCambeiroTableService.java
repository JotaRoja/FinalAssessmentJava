package com.assessments.finalAssessmentJava.services;

import com.assessments.finalAssessmentJava.models.UsersInfo;
import java.util.List;

public interface XianCambeiroTableService {
    public UsersInfo getInfo(int id);
    public List<UsersInfo> getAll();
    public String createInfo(UsersInfo info);
    public String updateInfo(UsersInfo info);
    public String deleteInfo(int id);
}
