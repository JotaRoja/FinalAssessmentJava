package com.assessments.finalAssessmentJava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalAssessmentJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
